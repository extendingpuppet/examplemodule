require 'spec_helper'
describe 'examplemodule' do
  context 'with default values for all parameters' do
    it { should contain_class('examplemodule') }
  end
end
